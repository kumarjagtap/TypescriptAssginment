/* Create an arrow function by which will take multiple strings and you have print each 
string along with length of each string */
var strleng :number;
var strwithlength = strCheck(...names:string[]): string =>{
	return strwithlength;
}
let allnames = strCheck("nitin","sumit","rahul","mayur");

console.log(strwithlength);