var __spreadArray = (this && this.__spreadArray) || function (to, from) {
    for (var i = 0, il = from.length, j = to.length; i < il; i++, j++)
        to[j] = from[i];
    return to;
};
/* Create an arrow function by which will take multiple strings and you have print each
string along with length of each string */
var strleng;
var strwithlength = strCheck.apply(void 0, __spreadArray(__spreadArray([], names), [string[]])), string;
{
    return strwithlength;
}
var allnames = strCheck("nitin", "sumit", "rahul", "mayur");
console.log(strwithlength);
